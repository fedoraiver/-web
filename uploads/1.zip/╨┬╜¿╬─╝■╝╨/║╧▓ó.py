import cv2 as cv
import numpy as np
import math
from keras_8testconvnet import pred

# 这个函数用于展示图片
def cv_show(nickname, name):
    cv.imshow(nickname, name)
    cv.waitKey(0)
    cv.destroyAllWindows()


# 这个函数实现按从左到右或从上到下的顺序对图片中的轮廓进行排序
def sort_contours(cnt, method="left-to-right"):
    reverse = False
    i = 0
    if method == "top-to-bottom" or method == "bottom-to-top":
        i = 1
    if method == "right-to-left" or method == "bottom-to-top":
        reverse = True
    boundingBoxes = [cv.boundingRect(c) for c in cnt]
    (cnt, boundingBoxes) = zip(*sorted(zip(cnt, boundingBoxes), key=lambda b: b[1][i], reverse=reverse))
    return cnt, boundingBoxes


# 这个函数获得原图像的四个坐标点
def order_points(pts):
    # 初始化坐标点
    rect = np.zeros((4, 2), dtype="float32")
    # 获取左上角和右下角坐标点
    s = pts.sum(axis=1)  # 每行像素值进行相加；若axis=0，每列像素值相加
    rect[0] = pts[np.argmin(s)]  # top_left返回s首个最小值索引
    rect[2] = pts[np.argmax(s)]  # bottom_left返回s首个最大值索引
    # 分别计算左上角和右下角的离散差值
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]

    return rect


# 这个函数对图像进行透视变换以实现翻转的功能
def Four_Points_Transform(img, pts):
    # 获取坐标点，并将它们分离开来
    rect = order_points(pts)
    (tl, tr, br, bl) = rect
    # 计算新图片的宽度指，选取水平差值的最大值
    widthA = np.sqrt(((br[0]-bl[0])**2)+((br[1]-bl[1])**2))
    widthB = np.sqrt(((tr[0]-tl[0])**2)+((tr[1]-tl[1])**2))
    maxwidth = max(int(widthA), int(widthB))
    # 计算新图片的高度值，选取垂直差值的最大值
    heightA = np.sqrt(((bl[0]-tl[0])**2)+((bl[1]-tl[1])**2))
    heightB = np.sqrt(((br[0]-tr[0])**2)+((br[1]-tr[1])**2))
    maxheight = max(int(heightA), int(heightB))
    # 构建新图片的4个坐标点，左上角为原点
    dst = np.array([
                [0, 0],
                [maxwidth-1, 0],
                [maxwidth-1, maxheight-1],
                [0, maxheight-1]], dtype="float32")
    # 获取透视变换矩阵并应用它
    M = cv.getPerspectiveTransform(rect, dst)
    # 进行透视变换
    warped = cv.warpPerspective(img, M, (maxwidth, maxheight))
    return warped


# 这个函数实现通过鼠标点击获取坐标
def on_mouse(event, x, y, flags, param):
    # 鼠标在原图像点击，获取矩形的四个边角点坐标
    global timg, points
    img2 = timg.copy()
    p0 = (0, 0)  # 初始化
    if event == cv.EVENT_LBUTTONDOWN:
        p1 = (x, y)
        points.append([x, y])
        # print(p1)

        # 在点击图像处绘制图
        cv.circle(img2, p1, 4, (0, 255, 0), 4)
        cv.imshow('origin', img2)
    return p0


if __name__ == "__main__":
    global points, timg
    xscale, yscale = 5, 5  # 通过放大图像使点击位置更精确
    points = []

    template = cv.imread(r"C:\Users\付钰森\Desktop\新建文件夹\ee5ed01d8bee13c98e80adc7303fb5f.jpg")
    choice = input("请问你需要调整图片摆放角度吗？(请回答y/n)")
    if choice == 'y':
        shape = template.shape
        timg = cv.resize(template, (int(shape[1]/xscale), int(shape[0]/yscale)))  # 放大图像
        # print(timg.shape)
        cv.imshow('origin', timg)
        cv.setMouseCallback('origin', on_mouse)  # 此处设置显示的图片名称一定要和上一句以及on_mouse函数中设置的一样
        cv.waitKey(0)
        cv.destroyAllWindows()

        # 还原像素位置
        points = np.array(points, dtype=np.float32)
        points[:, 0] *= shape[1] / int(shape[1]/xscale)
        points[:, 1] *= shape[0] / int(shape[0]/yscale)
        warped = Four_Points_Transform(template, points)
        warped = cv.resize(warped, (500, 400))
        cv_show('results', warped)
        template = warped.copy()


template = cv.cvtColor(template, cv.COLOR_BGR2GRAY)
rectKernel = cv.getStructuringElement(cv.MORPH_RECT, (9, 3))
img2 = cv.resize(template, (500, 400))
cv_show('i', img2)


img = cv.morphologyEx(img2, cv.MORPH_BLACKHAT, rectKernel)

cv_show('t', img)
img = img.astype('uint8')

thresh = cv.adaptiveThreshold(img, 255, cv.ADAPTIVE_THRESH_GAUSSIAN_C, cv.THRESH_BINARY_INV, 7, 18)
cv_show('th', thresh)
thresh = cv.dilate(thresh, rectKernel)
cv_show('th', thresh)
contours, hierarchy = cv.findContours(thresh.copy(), cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)


# 对轮廓进行排序
contours = sort_contours(contours, method="top-to-bottom")[0]
# 用来储存符号面积要求轮廓的空列表
contours_list = []
for (i, c) in enumerate(contours):
    area = cv.contourArea(c)
    if area < 200:
        continue
    contours_list.append(c)

# 测出轮廓列表的长度
len1 = len(contours_list)

# 将轮廓列表中的轮廓按坐标上下顺序排序，注意这一步之后列表转化成了元组
contours_list = sort_contours(tuple(contours_list), method="top-to-bottom")[0]
# 将元组转化回列表
contours_list_lst = list(contours_list)
# 将每行的第一个用列表中的第一个轮廓初始化
rowstart = contours_list_lst[0]
i = 1

contours_sorted = []  # 储存排序后轮廓的空列表
count, row, column = 0, 0, 0
while i < len1:
    contours_group = []  # 以每行为一组储存轮廓
    contours_group.append(rowstart)
    while i < len1:
        # 计算列表中相邻轮廓的纵坐标差
        dif = cv.boundingRect(rowstart)[1] - cv.boundingRect(contours_list_lst[i])[1]

        if math.fabs(dif) > 20:  # 大于20，认为在不同行
            rowstart = contours_list_lst[i]  # 更新行头元素
            i = i + 1
            # 计数变量count，只标记第一次换行，用以判断矩阵有多少列
            count = count + 1
            break  # 跳出这层循环

        contours_group.append(contours_list_lst[i])
        i = i+1

    if count == 1:
        # 确定矩阵的列数
        column = i - 1

    # 以每行为一组按从左到右的顺序进行排序
    contours_group = sort_contours(tuple(contours_group), method="left-to-right")[0]
    # 转化回列表
    contours_group_lst = list(contours_group)
    # 将该组列表拼接到已排好序的轮廓列表上
    contours_sorted.extend(contours_group_lst)

contours_sorted = tuple(contours_sorted)
# 元素总数除以列数得到行数
row = int(len1 / column)

# 设置空字典
digits = {}

for (i, c) in enumerate(contours_sorted):
    (x, y, w, h) = cv.boundingRect(c)
    # 从模板图片上取出对应的区域
    roi = img2[y:y+h, x:x+w]
    # 调整大小
    roi = cv.resize(roi, (100, 150))
    roi = cv.threshold(roi, 130, 255, cv.THRESH_BINARY_INV)[1]
    # roi = cv.copyMakeBorder(roi,50,50,75,75,cv.BORDER_CONSTANT,value=0)
    # cv_show('r',roi)
    roi = cv.resize(roi, (500, 400))
    # cv_show('r',roi)
    # plt.imshow(roi,cmap="Greys")
    # plt.show()
    digits[i] = roi
# cv.imwrite('0.1.png',digits[0])
# cv.imwrite('1.1.png',digits[1])
# cv.imwrite('2.1.png',digits[2])
# cv.imwrite('3.1.png',digits[3])
# cv.imwrite('4.1.png',digits[4])
# cv.imwrite('5.1.png',digits[5])
# cv.imwrite('6.1.png',digits[6])
# cv.imwrite('7.1.png',digits[7])
# cv.imwrite('8.1.png',digits[8])
# cv.imwrite('9.1.png',digits[9])

matrix_list = []
for j in digits:
    # digits1在每轮该级循环开始时要被清空
    digits1 = []
    erode = cv.erode(digits[j], rectKernel)
    contours1, hierarchy1 = cv.findContours(erode.copy(), cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
    contours1 = sort_contours(contours1, method="left-to-right")[0]
    for (k, c1) in enumerate(contours1):
        # 绘出每一个轮廓的外接矩形
        area1 = cv.contourArea(c1)
        if area1 < 4000:
            continue
        (x, y, w, h) = cv.boundingRect(c1)
        roi1 = erode[y:y+h, x:x+w]
        pshape = roi1.shape
        if pshape[0] >= pshape[1]:
            max = pshape[0]
        else:
            max = pshape[1]

        vertical = int((max - pshape[0]) / 2)
        horizontal = int((max - pshape[1]) / 2)  
        roi1 = cv.copyMakeBorder(roi1,vertical,vertical,horizontal,horizontal,cv.BORDER_CONSTANT)
        roi1 = cv.copyMakeBorder(roi1,28,28,28,28,cv.BORDER_CONSTANT)
        # cv_show('r', roi1)
        cv.imwrite('roi.png', roi1)
        res = pred("D:/python/roi.png")
        digits1.append(res)

    # print(digits1)
    sum = 0
    for i in range(0, len(digits1)):
        sum += digits1[i]*10**(len(digits1)-i-1)

    matrix_list.append(sum)

matrix = np.array(matrix_list)
print(matrix.shape)
matrix = matrix.reshape((row,column))
file = open(r"\\10.250.134.95\uploads\3.txt",'w')
print(matrix,file=file)
print("行数:", row, "列数:", column,file=file)
file.close()